FRAMEWORKS = ["fastapi", "flask", "asgi"]
